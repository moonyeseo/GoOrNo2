package alarm.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import users.model.UsersBean;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
	
	@Autowired
    private NotificationService notificationService;

    @RequestMapping(value = "/subscribe", method = RequestMethod.GET)
    public SseEmitter subscribe(HttpServletRequest request) {
        UsersBean usersBean = (UsersBean) request.getSession().getAttribute("usersBean");
        return notificationService.createEmitter(usersBean.getUser_no());
    }
	
}